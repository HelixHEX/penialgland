<?php

/**
 * @file
 * Contains \Drupal\Core\Entity\EntityMalformedException.
 */

namespace Drupal\Core\Entity;

/**
 * Defines an exception thrown when a malformed entity is passed.
 */
class EntityMalformedException extends \Exception { }
